# Credits

## Original contributors
---
* Eduardo Díaz ([ediazrod](https://github.com/ediazrod)). Documentation and testing
* Luis Javier Fernández ([luisjfdez](https://github.com/luisjfdez)). Main original developer
* Gonzalo Fiuza ([gontxu7](https://github.com/gontxu7)). Documentation and testing 
* Juan Carlos Rodríguez. Original idea

