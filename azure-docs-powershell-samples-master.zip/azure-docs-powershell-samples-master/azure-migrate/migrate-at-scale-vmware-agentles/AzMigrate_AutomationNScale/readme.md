---
title: Automate agentless VMware migrations in Azure Migrate
description: Describes how to use scripts to migrate a large number of machines in Azure Migrate
author: snehaamicrosoft
ms.service: azure-migrate
ms.topic: article
ms.date: 04/01/2019
ms.author: snehaa
---


# Scale migration of VMware VMs 

This article helps you understand how to use scripts to migrate large number of VMware virtual machines (VMs) using the agentless method. To scale migrations, you use [Azure Migrate PowerShell module](../site-recovery/site-recovery-overview.md). 

The Azure Migrate VMware migration automation scripts are available for download at [Azure PowerShell Samples](https://github.com/Azure/azure-docs-powershell-samples/tree/master/azure-migrate/migrate-at-scale-with-site-recovery) repo on GitHub. The scripts can be used to migrate VMware VMs to Azure using the agentless migration method. The Azure Migrate PowerShell commands used in these scripts are documented [here].

## Current limitations
- These scripts support migration of VMware VMs with all disks. You can update the scripts if you want to selectively replicate the disks attached to a VMware VM. 
- The scripts support use of assessment recommendations. If assessment recommendations are not used, then all disks attached to the VMware VM are migrated to the same managed disk type (Standard or Premium). You can update the scripts if you want to use multiple types of managed disks with the same VM

## Prerequisites

1. [Complete the discovery tutorial](tutorial-discover-vmware.md) to prepare Azure and VMware for migration.
2. We recommend that you complete the second tutorial to [assess VMware VMs](tutorial-assess-vmware.md) before migrating them to Azure.
3. You have the Azure PowerShell `Az` module. If you need to install or upgrade Azure PowerShell, follow this [guide to install and configure Azure PowerShell](/powershell/azure/install-az-ps)

## Install Azure Migrate PowerShell module

Azure Migrate PowerShell module is available in preview. You'll need to install the PowerShell module using the following command. 

```azurepowershell
Install-Module -Name Az.Migrate 
```

## CSV input file
Once you have all the pre-requisites completed, you need to create a CSV file which has data for each source VM that you want to migrate. All the scripts are designed to work on the same CSV file. A sample CSV template is available in the scripts folder for your reference. 
The csv file is configurable so that you can use assessment recommendations and even specify if certain operations are not be triggered for a particular VM. 

> [!NOTE]
> The same csv file can be used to migrate VMs in multiple Azure Migrate projects.

### CSV file schema

**Column Header** | **Description**
--- | ---
AZMIGRATEPROJECT_SUBSCRIPTION_ID | Provide Azure Migrate project subscription ID.
AZMIGRATEPROJECT_RESOURCE_GROUP_NAME | Provide Azure Migrate resource group name.
AZMIGRATEPROJECT_NAME | Provide the name of the Azure Migrate project in which you want to migrate servers. 
SOURCE_MACHINE_NAME | Provide the friendly name (display name) for the discovered VM in the Azure Migrate project.
AZMIGRATEASSESSMENT_NAME | Provide the name of assessment which needs to be leveraged for migration.
AZMIGRATEGROUP_NAME | Provide the name of the group which was used for the Azure Migrate assessment.
TARGET_RESOURCE_GROUP_NAME | Provide the name of the Azure resource group to which the VM needs to be migrated to.
TARGET_VNET_NAME| Provide the name of the Azure Virtual Network which the migrated VM should use.
TARGET_SUBNET_NAME | Provide the name of the subnet in the target virtual network that the migrated VM should use. If left blank, then “default” subnet will be used.
TARGET_MACHINE_NAME | Provide the name that the migrated VM should use in Azure. If left blank, then the source machine name will be used.  
TARGET_MACHINE_SIZE | Provide the SKU that the VM should use in Azure. To migrate a VM to D2_v2 VM in Azure, specify the value in this field as "Standard_D2_v2". If you use an assessment, then this value will be dervived based on assessment recommendation.
LICENSE_TYPE | Specify if you want to use Azure Hybrid Benefit for Windows Server VMs. Use value "WindowsServer" to take advantage of Azure Hybrid Benefit. Otherwise leave blank or use "NoLicenseType".
OS_DISK_ID | Provide the OS disk ID for the VM to be migrated. The disk ID to be used is the unique identifier (UUID) property for the disk retrieved using the Get-AzMigrateServer cmdlet. The script will use the first disk of the VM as the OS disk in case no value is provided.
TARGET_DISKTYPE | Provide the disk type to be used for all disks of the VM in Azure. Use 'Premium_LRS' for premium managed disks, 'StandardSSD_LRS' for standard SSD disks and 'Standard_LRS' to use standard HDD disks. If you choose to use an assessment, then the script will prioritize using recommended disk types for each disk of the VM. If you do not use assessment or specify any value, the script will use standard HDD disks by default.    
AVAILABILITYZONE_NUMBER | Specify the availability zone number to be used for the migrated VM. You can leave this blank in case you do not want to use availability zones. 
AVAILABILITYSET_NAME | Specify the name of the availability set to be used for the migrated VM. You can leave this blank in case you do not want to use availability set.
TURNOFF_SOURCESERVER | Specify 'Y' if you want to turn off source VM at the time of migration. Use 'N' otherwise. If left blank, then the script assumes the value as 'N'.
TESTMIGRATE_VNET_NAME | Specigy the name of the virtual network to be used for test migration.
UPDATED_TARGET_RESOURCE_GROUP_NAME | If you want to update the resource group to be used by the migrated VM in Azure, then specify the name of the Azure resource group, else leave blank. 
UPDATED_TARGET_VNET_NAME | If you want to update the Virtual Network to be used by the migrated VM in Azure, then specify the name of the Azure Virtual Network, else leave blank.
UPDATED_TARGET_MACHINE_NAME | If you want to update the name to be used by the migrated VM in Azure, then specify the new name to be used, else leave blank.
UPDATED_TARGET_MACHINE_SIZE | If you want to update the SKU to be used by the migrated VM in Azure, then specify the new SKU to be used, else leave blank.
UPDATED_AVAILABILITYZONE_NUMBER | If you want to update the availability zone to be used by the migrated VM in Azure, then specify the new availability zone to be used, else leave blank.
UPDATED_AVAILABILITYSET_NAME | If you want to update the availability set to be used by the migrated VM in Azure, then specify the new availability set to be used, else leave blank.
UPDATE_NIC1_ID | Specify the ID of the NIC to be updated. 
UPDATED_TARGET_NIC1_SELECTIONTYPE | Specify the value to be used for this NIC. Use "Primary","Secondary" or "DoNotCreate" to specify if this NIC should be the primary, secondary, or not to be created on the migrated VM. Only one NIC can be specified as the primary NIC for the VM. Leave blank if you don't want to update.
UPDATED_TARGET_NIC1_SUBNET_NAME | Specify the name of the subnet to used for the NIC on the migrated VM. Leave blank if you don't want to update.
UPDATED_TARGET_NIC1_IP | Specify the IPv4 address to be used by the NIC on the migrated VM if you want to use static IP. Use "auto" if you want to automatically assign the IP. Leave blank if you don't want to update.
UPDATE_NIC2_ID | Specify the ID of the NIC to be updated. 
UPDATED_TARGET_NIC2_SELECTIONTYPE | Specify the value to be used for this NIC. Use "Primary","Secondary" or "DoNotCreate" to specify if this NIC should be the primary, secondary, or not to be created on the migrated VM. Only one NIC can be specified as the primary NIC for the VM. Leave blank if you don't want to update.
UPDATED_TARGET_NIC2_SUBNET_NAME | Specify the name of the subnet to used for the NIC on the migrated VM. Leave blank if you don't want to update.
UPDATED_TARGET_NIC2_IP | Specify the IPv4 address to be used by the NIC on the migrated VM if you want to use static IP. Use "auto" if you want to automatically assign the IP. Leave blank if you don't want to update.
OK_TO_UPDATE | Use 'Y' to indicate whether the VM properties need to be updated when you run the AzMigrate_UpdateMachineProperties script. Use 'N' or leave blank otherwise.
OK_TO_MIGRATE | Use 'Y' to indicate whether the VM should be migrated when you run the AzMigrate_StartMigration script. Use 'N' or leave blank if you don't want to migrate the VM. 
OK_TO_USE_ASSESSMENT | Use 'Y' to indicate whether the VM should start replication using assessment recommendations when you run the AzMigrate_StartReplication script. This will override the TARGET_MACHINE_SIZE and TARGET_DISKTYPE values in the csv file. Use 'N' or leave blank if you do not want to use assessment recommendations.
OK_TO_TESTMIGRATE | Use 'Y' to indicate whether the VM should be test migrated when you run the AzMigrate_StartTestMigration script. Use 'N' or leave blank if you do not want to test migrate the VM. 
OK_TO_RETRIEVE_REPLICATIONSTATUS | Use 'Y' to indicate whether the replication status of the VM should be updated when you run the AzMigrate_ReplicationStatus script. Use 'N' or leave blank if you do not want to update the replication status.
OK_TO_CLEANUP | Use 'Y' to indicate whether the replication for the VM should be cleaned up when you run the AzMigrate_StopReplication script. Use 'N' or leave blank otherwise.
OK_TO_TESTMIGRATE_CLEANUP | Use 'Y' to indicate whether the test migration for the VM should be cleaned up when you run the AzMigrate_CleanUpTestMigration script. Use 'N' or leave blank otherwise.


## Script execution

Once the CSV is ready, you can execute the following steps to perform migration of the on-premises VMs:

**Step #** | **Script Name** | **Description**
--- | --- | ---
1 | AzMigrate_StartReplication.ps1 | Enable replication for all the VMs listed in the csv, the script creates a CSV output and a log file for troubleshooting.
2 | AzMigrate_ReplicationStatus.ps1 | Check the status of replication, the script creates a csv with the status for each VM.
3 | AzMigrate_UpdateMachineProperties.ps1 | Once the VMs have completed initial replication, use this script to update the target properties of the VM (Compute and Network properties). The script creates a CSV output with the job details for each VM.
4 | AzMigrate_StartTestMigration.ps1 |  Start the test failover for all VMs listed in the csv which are configured for test migration. The script creates a CSV output with the job details for each VM.
5 | AzMigrate_CleanUpTestMigration.ps1 | Once you manually validate the VMs that were test failed-over, use this script to clean up the test failover VMs for all VMs listed in the csv which are configured for test migration cleanup. The script creates a CSV output with the job details for each VM.
6 | AzMigrate_StartMigration.ps1 | Start the test failover for all VMs listed in the csv which are configured for migration. The script creates a CSV output with the job details for each VM.
7 | AzMigrate_StopReplication.ps1 | Removes the Replication which can be done after successful migration or if you want to cancel the replication. The script creates a CSV output with the job details for each VM.


The following scripts are invoked by other scripts for all Azure Migrate operations like enabling replication, starting test migration, updating VM properties and so on. Ensure that all the scripts are present in the same folder/path. 

**Step #** | **Script Name** | **Description**
--- | --- | ---
1 | AzMigrate_Shared.ps1 | Common script containing functions for retrieving assessment properties (through API), and validations for discovered VMs and replicating VMs. 
2 | AzMigrate_CSV_Processor.ps1 | Common script containing functions used for csv file operations including loading, reading, and printing for logs. 
3 | AzMigrate_Logger.ps1 | Common script invoked for generating the log file for Azure Migrate automation operations. The log file will be of the format log.Scriptname.Datetime.txt.

In addition to the above, the folder also contains AzMigrate_Template.ps1 that contains the skeleton framework for building custom scripts for different Azure Migrate operations. 

### Script execution syntax

Once you have downloaded the scripts, the scripts can be executed as follows.

If you want to execute the script to initiate replication for VMs using the Input.csv file, then use the following syntax. 

```azurepowershell
".\AzMigrate_StartReplication.ps1" .\Input.csv 
```

To learn more about using Azure PowerShell for migrating VMware VMs with Azure Migrate, follow the [tutorial](https://aka.ms/azuremigratepowershellvmware).